 /**

no JS here . . . 

  # made in 2016 by Nazar The Vis Azhar
  # last code updated on 11/November/2022
  # https://www.nazarazhar.com/

I just wanted to make people happy :)

**/
