# Outer Space Background

A Pen created on CodePen.io. Original URL: [https://codepen.io/NazarAzhar/pen/zqXMqP](https://codepen.io/NazarAzhar/pen/zqXMqP).

