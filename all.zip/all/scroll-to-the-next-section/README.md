# Scroll to the next section

A Pen created on CodePen.io. Original URL: [https://codepen.io/umarhamza/pen/nyrwey](https://codepen.io/umarhamza/pen/nyrwey).

Forked from Jordi Casamiquela